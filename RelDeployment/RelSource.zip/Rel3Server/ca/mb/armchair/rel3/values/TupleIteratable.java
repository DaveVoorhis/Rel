package ca.mb.armchair.rel3.values;

public interface TupleIteratable {
	public TupleIterator iterator();
}
