package ca.mb.armchair.rel3.types.userdefined;

public class MultipleInheritance {

	public void addScalarTypeName(String name) {
	}
	
}
