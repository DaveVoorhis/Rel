package ca.mb.armchair.rel3.client;

public class Type {
	Type() {}
}
