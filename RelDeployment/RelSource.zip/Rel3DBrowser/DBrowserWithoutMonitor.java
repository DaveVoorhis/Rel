import ca.mb.armchair.rel3.dbrowser.ui.Browser;

/** Alternative startup without execution monitor.  Useful when developing and debugging DBrowser itself. */
public class DBrowserWithoutMonitor {	
	public static void main(String args[]) {
			Browser.main(args);
	}
}
