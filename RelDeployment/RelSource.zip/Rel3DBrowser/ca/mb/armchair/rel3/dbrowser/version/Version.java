package ca.mb.armchair.rel3.dbrowser.version;

public class Version {
	public static String getVersion() {
		return "DBrowser 2.16";
	}

	public static String getCopyright() {
		return "Copyright &copy 2004 - 2014 Dave Voorhis";
	}
}
