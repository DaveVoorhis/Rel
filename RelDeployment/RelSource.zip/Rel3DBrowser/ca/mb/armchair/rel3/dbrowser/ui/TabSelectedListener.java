package ca.mb.armchair.rel3.dbrowser.ui;

public interface TabSelectedListener {
	public void tabSelected(java.awt.Component component, String title);
}
